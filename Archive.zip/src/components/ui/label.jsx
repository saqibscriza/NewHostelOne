import * as React from "react";
import { Label as LabelPrimitive } from "radix-ui";
import { cn } from "../../lib/utils";

function Label({ className, ...props }) {
  return (
    <LabelPrimitive.Root
      data-slot="label"
      className={cn(
        /**
         * ✅ FIX: added text-foreground
         * 👉 ensures label is visible in dark mode
         */
        "flex items-center gap-2 text-sm font-medium leading-none text-foreground select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50",
        className,
      )}
      {...props}
    />
  );
}

export { Label };
